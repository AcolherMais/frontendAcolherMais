document.querySelectorAll('.displayCinzaFAQ').forEach(item => {
    item.addEventListener('click', () => {
        item.classList.toggle('ativo');
    });
});


